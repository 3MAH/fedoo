.. automodule:: fedoo.constitutivelaw
   :no-members:
   :no-inherited-members:
   :no-special-members:

