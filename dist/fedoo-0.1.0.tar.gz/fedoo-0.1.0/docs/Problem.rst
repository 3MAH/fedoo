.. automodule:: fedoo.problem
   :no-members:
   :no-inherited-members:
   :no-special-members:

