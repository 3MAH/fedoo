Welcome to FEDOO's documentation!
=================================


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Overview
   Install
   Quick_Start  
   Mesh
   ConstitutiveLaw
   WeakForm
   Assembly   
   Problem
   post-treatment
   Examples

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
