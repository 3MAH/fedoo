.. automodule:: fedoo.weakform
   :no-members:
   :no-inherited-members:
   :no-special-members:

