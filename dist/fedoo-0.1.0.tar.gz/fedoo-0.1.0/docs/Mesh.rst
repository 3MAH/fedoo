.. automodule:: fedoo.mesh
   :no-members:
   :no-inherited-members:
   :no-special-members:

