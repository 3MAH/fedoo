Installation
=================================

It is highly recommended to use ANACONDA for a simple installation of Fedoo coming with all the dependences and available on Linux, Windows or MacOS.

1. Download and Install ANACONDA (https://www.anaconda.com/) or Miniconda (https://docs.conda.io/en/latest/miniconda.html). 

2. To install Fedoo with conda :

.. code-block:: none

   $ conda install -c conda-forge -c set3mah fedoo


