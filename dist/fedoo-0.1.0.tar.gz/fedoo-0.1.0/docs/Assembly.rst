Class Assembly
=================================

.. autoclass:: fedoo.Assembly
    :members:


