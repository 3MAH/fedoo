#!/bin/bash
cp -r $SRC_DIR/fedoo $SP_DIR