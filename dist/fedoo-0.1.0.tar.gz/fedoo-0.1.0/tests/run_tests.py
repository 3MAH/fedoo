# -*- coding: utf-8 -*-
"""
Created on Mon Jan 31 14:20:18 2022

@author: Etienne
"""

import pytest

pytest.main()